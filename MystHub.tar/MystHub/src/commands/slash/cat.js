const Slash = require('../../structs/templates/Slash');
const { MessageEmbed } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const axios = require('axios');
const path = require('path');

class CatCommand extends Slash {

	constructor(client) {
		super(client, {
			name        : 'cat',
			description : 'Responds with a random cat picture.',
			usage       : 'cat',
			directory   : __dirname,
			userPerms   : 'SEND_MESSAGES',
			guildOnly   : true,
		});
	}

	async run(interaction) {
		const response = await axios.get('https://aws.random.cat/meow');
		const CatEmbed = new MessageEmbed()
			.setTitle('**😍 | Awwwww | 😍**')
			.setImage(response.data.file)
			.setFooter({
				text: `Requested by ${interaction.user.tag} • ${this.client.config.embed.footer}`,
				iconURL: this.client.user.displayAvatarURL(),
			});
		return interaction.reply({
			embeds: [CatEmbed],
		});
	}

	command() {
		const command = new SlashCommandBuilder()
			.setName(this.name)
			.setDescription(this.description)
			.setDefaultPermission(true);
		return command;
	}
}

module.exports = CatCommand;
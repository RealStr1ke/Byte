const Client = require('./src/structs/MystHub');
const MystHub = new Client();

MystHub.init();
MystHub.start();

process.on('rejectionHandled', (err) => console.error(err));
process.on('unhandledRejection', (err) => console.error(err));
process.on('uncaughtException', (err) => console.error(err));
